with open("mydefaults.ini.txt") as ini_file:
    data = ini_file.read()
lower = 0
upper = 0
digit = 0

for char in data:
    if char.islower():
        lower += 1
    elif char.isupper():
        upper += 1
    elif char.isdigit():
        digit += 1

print(f'The number of lowercase letters is: {lower}')
print(f'The number of uppercase letters is: {upper}')
print(f'The number of digits is: {digit}')
    